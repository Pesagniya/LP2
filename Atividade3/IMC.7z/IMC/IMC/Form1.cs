﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMC
{
    public partial class Form1 : Form
    {
        double peso, altura, result;

        public Form1()
        {
            InitializeComponent();
        }

        private void TxtResult_TextChanged(object sender, EventArgs e)
        {
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtResult.Clear();
            mskbxAltura.Clear();
            mskbxPeso.Clear();
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            peso = Convert.ToDouble(mskbxPeso.Text);
            altura = Convert.ToDouble(mskbxAltura.Text);
            result = Math.Round(peso / (altura * altura), 1);
            txtResult.Text = Convert.ToString(result);

            if (result < 18.5)
                MessageBox.Show("Magro; Grau de Obesidade = 0.");
            else if (result < 25)
                MessageBox.Show("Normal; Grau de Obesidade = 0.");
            else if (result < 30)
                MessageBox.Show("Acima do peso; Grau de Obesidade = I.");
            else if (result < 40)
                MessageBox.Show("Obeso; Grau de Obesidade = II.");
            else if (result <= 40)
                MessageBox.Show("Obesidade Grave; Grau de Obesidade = III.");
            else
                MessageBox.Show("Erro; Divisão por 0.");
        }

        private void BtnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

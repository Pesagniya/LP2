﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PProva
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnEx_Click(object sender, EventArgs e)
        {
            int[,] vetor = new int[4, 3];
            double[] vetorMedia = new double[4];
            double mediaGeral;
            int N = 4, result = 0; // 0030482221021
            string aux = "";

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    aux = Interaction.InputBox("Entrada de pontos: " + (i + 1).ToString(), "Entrada de dados");
                    if ((!int.TryParse(aux, out result)) || (result <= 0))
                    {
                        MessageBox.Show("Entrada inválida.");
                        j--;
                    }
                    else
                        vetor[i, j] = result;
                }
                vetorMedia[i] = Convert.ToDouble((vetor[i, 0] + vetor[i, 1] + vetor[i, 2]) / 3);
            }

            for (int i = 0; i < N; i++)
                lstbxJogadores.Items.Add("Jogador: " + (i + 1).ToString() + " Pontos Nível Fácil: " + vetor[i, 0].ToString() +
                    " Pontos Nível Médio: " + vetor[i, 1].ToString() + " Pontos Nível Díficil: " + vetor[i, 2].ToString() + " Média Pontos: " + vetorMedia[i].ToString("N2"));

            lstbxJogadores.Items.Add("-------------------------");
            mediaGeral = (vetorMedia[0] + vetorMedia[1] + vetorMedia[2]) / 3;
            lstbxJogadores.Items.Add("Média Geral Jogadores : " + mediaGeral.ToString("N2"));
        }
    }
}

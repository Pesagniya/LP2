﻿namespace PProva
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEx = new System.Windows.Forms.Button();
            this.lstbxJogadores = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnEx
            // 
            this.btnEx.Location = new System.Drawing.Point(56, 148);
            this.btnEx.Name = "btnEx";
            this.btnEx.Size = new System.Drawing.Size(136, 102);
            this.btnEx.TabIndex = 0;
            this.btnEx.Text = "Executar";
            this.btnEx.UseVisualStyleBackColor = true;
            this.btnEx.Click += new System.EventHandler(this.BtnEx_Click);
            // 
            // lstbxJogadores
            // 
            this.lstbxJogadores.FormattingEnabled = true;
            this.lstbxJogadores.Location = new System.Drawing.Point(244, 72);
            this.lstbxJogadores.Name = "lstbxJogadores";
            this.lstbxJogadores.Size = new System.Drawing.Size(532, 290);
            this.lstbxJogadores.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lstbxJogadores);
            this.Controls.Add(this.btnEx);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEx;
        private System.Windows.Forms.ListBox lstbxJogadores;
    }
}

